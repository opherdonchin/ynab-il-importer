# Aikido status for 2026-03-25

## Main review file

- Proposed file: `data/paired/2026_03_25_aikido/aikido_full_backlog_to_current_proposed_transactions.csv`
- Review command:

```bash
pixi run python scripts/review_app.py --profile aikido --in "data/paired/2026_03_25_aikido/aikido_full_backlog_to_current_proposed_transactions.csv"
```

## Current state

- Combined backlog plus current window (`2025-11-01` through `2026-03-25`):
  - proposed rows: `68`
  - unique auto-mapped rows: `49`
  - remaining uncategorized rows: `19`
  - ready-only upload dry-run rows: `47`
- Backlog-only (`2025-11-01` through `2026-02-28`):
  - proposed rows: `49`
  - unique auto-mapped rows: `38`
  - remaining uncategorized rows: `11`
  - ready-only upload dry-run rows: `38`
- Current-only (`2026-03-01` through `2026-03-25`):
  - proposed rows: `19`
  - unique auto-mapped rows: `11`
  - remaining uncategorized rows: `8`
  - ready-only upload dry-run rows: `9`

## Remaining review-needed fingerprints

- `wodify aikido`
- `lyft`
- `sp tozando internati kiyoutoshi ka jp`
- `ups שינוע בינלאומי`
- `the integral dojo theintegr עסקת חו`
- `קבוצת נקר`
- `reuven mordechai`
- `lee office`
- `anatim meiron`
- `yaara yodfat`
- `יערה בן נחום`
- `bit`
- `רונן סרוסי`
- `גיא כהן`
- `בן וקנין`

## Important note

- Cross-budget reconciliation is still blocked until the historical backlog is reviewed and uploaded into Aikido, then reconciled.
